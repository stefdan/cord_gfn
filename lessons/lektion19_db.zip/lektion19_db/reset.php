<?php

require_once 'inc/konfiguration.inc.php';

CREATE TABLE IF NOT EXISTS eintraege (
    id INT PRIMARY KEY AUTO_INCREMENT,
    titel VARCHAR(255),
    erstellt_am DATE,
    author VARCHAR(50),
    inhalt TEXT
);

