<nav>
    <ul>
        <li><a href="index.php">Hauptseite</a></li>
        <li><a href="zeige_eintrag_formular.php">Neuer Eintrag</a></li>
        <li><a href="ausloggen.php">Ausloggen</a></li>
    </ul>
</nav>

<p>Eingeloggt als: <em><?php echo $_SESSION['eingeloggt']; ?></em></p>